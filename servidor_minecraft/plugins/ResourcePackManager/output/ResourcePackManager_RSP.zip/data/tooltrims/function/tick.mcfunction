# run migration if the setting is activated
execute if score $migration tooltrims.variable matches 1 as @a at @s run function tooltrims:migration/tick

# detect any leftovers from a used custom template
execute as @e[type=marker, tag=tooltrims.leftover] run function tooltrims:leftover/check_template