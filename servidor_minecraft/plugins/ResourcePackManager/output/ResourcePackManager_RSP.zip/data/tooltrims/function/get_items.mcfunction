loot give @s loot tooltrims:64_linear_templates
loot give @s loot tooltrims:64_tracks_templates
loot give @s loot tooltrims:64_charge_templates
loot give @s loot tooltrims:64_frost_templates